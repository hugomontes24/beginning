import random

# creer numero a decouvrir
m_list = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'] 
random.shuffle(m_list)
# for i in range(6):
# del m_list[-1]
# creer le numero à trouver
if int(m_list[0]) > 0:
    mystery_number = str(1000 * int(m_list[0]) + 100 * int(m_list[1]) + 10 * int(m_list[2]) + int(m_list[3]))
else:
    mystery_number = str(1000 * int(m_list[3]) + 100 * int(m_list[1]) + 10 * int(m_list[2]) + int(m_list[0]))
#print(str(mystery_number))

bon_digit = 0

while bon_digit < 4:
    try_list = []
    m_list = []

    # variables bons numeros
    m = 0
    bon_digit = 0
    # variables  numeros similaires

    try_number = str(input("Entrez un numero entre 1000 et 9999 :"))

    # creer listes
    for i in range(4):
        try_list += try_number[i]

    for i in range(4):
        m_list += mystery_number[i]

    # comparer bons numeros
    for i in range(4):
        if try_number[i] == mystery_number[i]:
            m = i - bon_digit
            del try_list[m], m_list[m]
            bon_digit += 1

    # numeros approximatifs
    mystery_ens = set(m_list)
    try_ens = set(try_list)
    similair_ens = (mystery_ens & try_ens)

    print("Bons numeros =", str(bon_digit), "Numeros similaires =", str(len(similair_ens)))
    # print("Numeros similaires =", str(len(similair_ens)))

# end game
print(mystery_number, " = ", try_number)
print("J'ai trouvé!!")
